<script src="<?= base_url("./js/hideFlash.js") ?>"></script>
<script src="<?= base_url("./js/liveSearch.js") ?>"></script>
</body>

</html>